@extends('layouts.app')

@section('header_styles')
    <link rel="stylesheet" type="text/css" href="https://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>



</style>
@stop

@section('content')
    <!-- Start Page Header-->
    <div class="page-header">
        <h1 class="title">Dashboard</h1>
        <ol class="breadcrumb">
            {{--<li class="active">This is a quick overview of some features</li>--}}
        </ol>
        <div class="right" style="top:30px;">
            <a href="{{route('tickets.create')}}" class="btn btn-default"><i class="fa fa-plus"></i>Create</a>
        </div>

    </div>
    @include('layouts.flash')


    <div class="container-widget">
        <div class="col-md-12">
            <br>
            <ul class="topstats clearfix">
                <li class="col-md-12">
                    <table id="example" class="table table-striped table-bordered responstable"  style="width:100%">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Subject</th>
                            {{--<th>Content</th>--}}
                            <th>Last Updated</th>
                            <th>Priority </th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>

                        @foreach($tickets as $ticket)
                        <tr>
                            <td>{{$ticket->id}}</td>


                            <td><a href="{{route('tickets.show' ,$ticket->id)}}" title="Click to Show the Ticket">{{$ticket->subject}}</a></td>
                            {{--<td>{{$ticket->content}}</td>--}}
                            <td>{{$ticket->updated_at->diffForHumans()}}</td>

                            <td>
                                @if ($ticket->priority === 'low')
                                    <span class="label label-success">{{ $ticket->priority }}</span>
                                @elseif ($ticket->priority === 'medium')
                                    <span class="label label-warning">{{ $ticket->priority }}</span>
                                @else
                                    <span class="label label-danger">{{ $ticket->priority }}</span>
                                @endif
                            </td>

                            <td>
                                @if ($ticket->status === 'open')
                                    <span class="label label-success">{{ $ticket->status }}</span>
                                @else
                                    <span class="label label-danger">{{ $ticket->status }}</span>
                                @endif
                            </td>

                            <td>

                                <a href="{{route('tickets.close' ,$ticket->id)}}" onclick="return confirm('are you sure to Mark as Closed the ticket ?')" title="Click to Close the Ticket"><i style="font-size: 15px; color: green" class="fa fa-thumbs-up"></i></a>
                                <a href="{{route('tickets.show' ,$ticket->id)}}" title="Click to Show the Ticket"><i style="font-size: 15px; color: blue" class="fa  fa-eye"></i></a>
                                <a href="{{route('tickets.delete' ,$ticket->id)}}" onclick="return confirm('are you sure to delete the ticket ?')" title="Click to Delete the Ticket"><i style="font-size: 15px; color: red" class="fa fa-trash-o"></i></a>
                            </td>

                        </tr>
                        @endforeach
                    </table>


                </li>
            </ul>
        </div>
        <!-- End Top Stats -->

    </div>
    <!-- END CONTAINER -->
    <!-- //////////////////////////////////////////////////////////////////////////// -->

    <!-- Start Footer -->
    <div class="row footer">

    </div>
    <!-- End Footer -->



@stop

@section('footer_scripts')

    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.3.min.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>

    <script>

        $(document).ready(function () {
            $('#example').DataTable(
                {
                    "pageLength": 25
                }
            );
        });

    </script>

@stop
