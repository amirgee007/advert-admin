@extends('layouts.app')

@section('header_styles')
    <style>

        .page-header { position: relative; }
        .reviews {
            color: #555;
            font-weight: bold;
            margin: 10px auto 20px;
        }
        .media .media-object { max-width: 120px; }
        .media-body { position: relative; }
        .media-date {
            position: absolute;
            right: 25px;
            top: 25px;
        }
        .media-date li { padding: 0; }
        .media-date li:first-child:before { content: ''; }
        .media-date li:before {
            content: '.';
            margin-left: -2px;
            margin-right: 2px;
        }
        .media-comment { margin-bottom: 20px; }
        .media-replied { margin: 0 0 20px 50px; }
        .media-replied .media-heading { padding-left: 6px; }

        .btn-circle span { padding-right: 6px; }

    </style>
@stop

@section('content')
    <!-- Start Page Header-->
    <div class="page-header">
        <h1 class="title">Show Ticket</h1>
        <ol class="breadcrumb">
            {{--<li class="active">This is a quick overview of some features</li>--}}
        </ol>
        <div class="right" style="top:30px;">
            <a href="{{route('tickets.create')}}" class="btn btn-default"><i class="fa fa-plus"></i>Create</a>
        </div>
    </div>



    <div class="container-widget">
        <div class="col-md-12">
            <br>
            <ul class="topstats clearfix">
                <li class="col-md-12">

                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    #{{ $ticket->id }} - {{ $ticket->subject }}
                                </div>

                                <div class="panel-body">
                                    @include('layouts.flash')

                                    <div class="ticket-info">
                                        <p>{{ $ticket->content }}</p>
                                        <p>Priority: {{ $ticket->priority }}</p>
                                        <p>
                                            @if ($ticket->status === 'Open')
                                                Status: <span class="label label-success">{{ $ticket->status }}</span>
                                            @else
                                                Status: <span class="label label-danger">{{ $ticket->status }}</span>
                                            @endif
                                        </p>
                                        <p>Created on: {{ $ticket->created_at->diffForHumans() }}</p>
                                    </div>

                                    <div>
                                        @foreach ($comments as $comment)
                                        <ul class="media-list">
                                            <li class="media">
                                                <a class="pull-left" href="#">
                                                    <img class="media-object img-circle" src="{{url('public/img/user.png')}}" alt="profile">
                                                </a>
                                                <div class="media-body" style="background-color: @if($ticket->user->id === $comment->user_id) {{"dodgerblue"}}@else{{"red"}}@endif">
                                                    <div class="well well-lg">
                                                        <h4 class="media-heading text-uppercase reviews">{{ $comment->user->name }} </h4>
                                                        <ul class="media-date text-uppercase reviews list-inline">
                                                            <li class="dd">{{ $comment->created_at->diffForHumans() }}</li>
                                                        </ul>
                                                        <p class="media-comment">
                                                            {{ $comment->content }}
                                                        </p>
                                                    </div>
                                                </div>

                                            </li>
                                        </ul>

                                        @endforeach
                                    </div>

                                    <hr>

                                    <div class="comment-form">
                                        @if($ticket->status=='open')
                                        <form action="{{ route('tickets.comment') }}" method="POST" class="form">
                                            {!! csrf_field() !!}

                                            <input type="hidden" name="ticket_id" value="{{ $ticket->id }}">

                                            <div class="form-group{{ $errors->has('comment') ? ' has-error' : '' }}">
                                                <textarea rows="10" id="content" class="form-control" name="content"></textarea>

                                                @if ($errors->has('content'))
                                                    <span class="help-block">
                                                        <strong>{{ $errors->first('content') }}</strong>
                                                    </span>
                                                @endif
                                            </div>

                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        </form>
                                        @else
                                        <div class="form-group">
                                            <button type="button" class="btn btn-danger btn-lg">Ticket Closed</button>
                                        </div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </li>
            </ul>
        </div>
        <!-- End Top Stats -->

    </div>
    <!-- END CONTAINER -->
    <!-- //////////////////////////////////////////////////////////////////////////// -->

    <!-- Start Footer -->
    <div class="row footer">

    </div>
    <!-- End Footer -->



@stop

@section('footer_scripts')


@stop
